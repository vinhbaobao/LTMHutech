/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package khobau;

/**
 *
 * @author Administrator
 */
import java.util.Scanner;

public class GiaiMaRuongKhoBau {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập đoạn code
        System.out.print("Nhập đoạn code: ");
        String code = scanner.nextLine();

        // Chuyển đổi chữ cái thành số và tính tổng
        int tong = 0;
        for (int i = 0; i < code.length(); i++) {
            char character = Character.toLowerCase(code.charAt(i));
            if (Character.isLetter(character)) {
                int so = character - 'a' + 1;
                tong += so;
            }
        }

        // Rút gọn cho đến khi nằm trong khoảng từ 1 đến 9
        while (tong > 9) {
            tong = tinhTongChuSo(tong);
        }

        // In ra chìa khóa mở rương
        System.out.println("Chìa khóa mở rương: " + tong);
    }

    // Hàm tính tổng các chữ số của một số
    public static int tinhTongChuSo(int so) {
        int tong = 0;
        while (so != 0) {
            tong += so % 10;
            so /= 10;
        }
        return tong;
    }
}

