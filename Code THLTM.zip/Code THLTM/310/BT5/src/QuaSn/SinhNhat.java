/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package QuaSn;

/**
 *
 * @author Administrator
 */
import java.util.Scanner;

public class SinhNhat {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Nhập ngày, tháng, năm sinh
        System.out.print("Nhập ngày sinh: ");
        int ngay = scanner.nextInt();

        System.out.print("Nhập tháng sinh: ");
        int thang = scanner.nextInt();

        System.out.print("Nhập năm sinh: ");
        int nam = scanner.nextInt();

        // Tính tổng các chữ số
        int tong = tinhTongChuSo(ngay) + tinhTongChuSo(thang) + tinhTongChuSo(nam);

        // Rút gọn cho đến khi nằm trong khoảng từ 1 đến 9
        while (tong > 9) {
            tong = tinhTongChuSo(tong);
        }

        // In ra món quà tương ứng
        switch (tong) {
            case 1:
                System.out.println("Vương miệng vàng");
                break;
            case 2:
                System.out.println("Đôi thiên nga vàng");
                break;
            case 3:
                System.out.println("Micro vàng");
                break;
            case 4:
                System.out.println("Khối lập phương vàng");
                break;
            case 5:
                System.out.println("Ngôi sao vàng");
                break;
            case 6:
                System.out.println("Trái tim vàng");
                break;
            case 7:
                System.out.println("Quyển sách vàng");
                break;
            case 8:
                System.out.println("8 đồng tiền vàng");
                break;
            case 9:
                System.out.println("Hoa sen vàng");
                break;
            default:
                System.out.println("Không có món quà phù hợp.");
        }
    }

    // Hàm tính tổng các chữ số của một số
    public static int tinhTongChuSo(int so) {
        int tong = 0;
        while (so != 0) {
            tong += so % 10;
            so /= 10;
        }
        return tong;
    }
}
