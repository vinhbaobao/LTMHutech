/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package B5_5;

/**
 *
 * @author Administrator
 */
import java.io.IOException;
import java.net.*;

public class Main {
    public static void main(String[] args) {
       
    try {
            InetAddress localAddress = InetAddress.getLocalHost();
            System.out.println("Local Host: " + localAddress.getHostAddress());

            Socket socket = new Socket("google.com.vn", 80);
            System.out.println("Connected to " + socket.getInetAddress() + " trong port " + socket.getPort() + " of " + socket.getLocalAddress());
            InetAddress remoteAddress = socket.getInetAddress();
           System.out.println("Remote Host: " + remoteAddress.getHostAddress());
           System.out.println("Remote Port: " + socket.getPort());

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
