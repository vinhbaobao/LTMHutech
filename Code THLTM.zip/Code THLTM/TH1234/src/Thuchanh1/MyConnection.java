//package Thuchanh1;
//
//import java.sql.*;
//import javax.swing.*;
//
//public class MyConnection {
//
//    public Connection getConnection() {
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            String URL = "jdbc:mysql://localhost/quanlytaikhoan?user=root&password=";
//            Connection con = DriverManager.getConnection(URL);
//            return con;
//        } catch (Exception ex) {
//            JOptionPane.showMessageDialog(null, ex.toString(), "Lỗi", JOptionPane.ERROR_MESSAGE);
//            return null;
//        }
//    }
//
//}
