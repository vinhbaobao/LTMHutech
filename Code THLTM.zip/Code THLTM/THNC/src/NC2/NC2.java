/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NC2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Administrator
 */
public class NC2 {
    
    public static void main(String[] args) {
        String[] fileNames = {"C:\\Folder\\file1.txt", "C:\\Folder\\file2.txt", "C:\\Folder\\file3.txt"};

        for (String fileName : fileNames) {
            System.out.println("Đang đọc file: " + fileName);
            readAndDisplayNumberLines(fileName);
            System.out.println();
        }
    }

    private static void readAndDisplayNumberLines(String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            int lineNumber = 1;
            while ((line = reader.readLine()) != null) {
                if (containsNumber(line)) {
                    // Chia nhỏ các số và hiển thị trên từng dòng riêng biệt
                    String[] numbers = line.split("\\s+");
                    for (String number : numbers) {
                        System.out.println("Dòng " + lineNumber + ": " + number);
                        lineNumber++;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Có lỗi xảy ra khi đọc file " + fileName + ": " + e.getMessage());
        }
    }

    private static boolean containsNumber(String line) {
        for (char c : line.toCharArray()) {
            if (Character.isDigit(c)) {
                return true;
            }
        }
        return false;
    }
}
